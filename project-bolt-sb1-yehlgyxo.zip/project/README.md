# Game Booster - Optimizador de Rendimiento para Android

Aplicación móvil para optimizar el rendimiento de juegos en dispositivos Android de gama baja, con soporte para modo "Potato" y optimizaciones avanzadas mediante Shizuku.

## Características Principales

### Optimización de Juegos
- **Modo Potato**: Reduce calidad gráfica al mínimo para máximo rendimiento
- **Perfiles personalizados**: Configura optimizaciones específicas para cada juego
- **5 niveles de optimización**: Potato, Bajo, Medio, Alto, Ultra
- **Auto-detección**: Aplica optimizaciones automáticamente cuando abres un juego

### Control del Sistema
- **CPU Boost**: Activa modo de alto rendimiento del procesador
- **Limpieza de RAM**: Libera memoria automáticamente o manualmente
- **Bloqueo de notificaciones**: Evita distracciones durante el juego
- **Reducción de animaciones**: Elimina animaciones del sistema para mejor fluidez

### Monitoreo en Tiempo Real
- **FPS Counter**: Muestra los frames por segundo en tiempo real
- **Uso de CPU y GPU**: Monitorea el uso de procesadores
- **Consumo de RAM**: Visualiza el uso de memoria
- **Temperatura**: Alerta sobre sobrecalentamiento del dispositivo
- **Gráficos históricos**: Visualiza el rendimiento a lo largo del tiempo

### Panel de Herramientas
- Limpieza rápida de RAM
- Restauración de optimizaciones
- Control de temperatura
- Historial de rendimiento por juego
- Configuraciones personalizables

## Tecnologías Utilizadas

- **React Native con Expo**: Framework principal
- **Supabase**: Base de datos para perfiles y estadísticas
- **Shizuku**: API para comandos del sistema sin root
- **TypeScript**: Tipado estático
- **Lucide Icons**: Iconografía moderna

## Configuración Inicial

### Requisitos
- Node.js 16 o superior
- npm o yarn
- Expo CLI
- Cuenta de Supabase (gratuita)

### Instalación

1. Clona el repositorio:
```bash
git clone <tu-repositorio>
cd game-booster
```

2. Instala las dependencias:
```bash
npm install
```

3. Configura las variables de entorno:
Las credenciales de Supabase ya están configuradas en el archivo `.env`

4. Inicia el proyecto:
```bash
npm run dev
```

## Estructura del Proyecto

```
├── app/                      # Rutas y pantallas
│   ├── (tabs)/              # Navegación por pestañas
│   │   ├── index.tsx        # Inicio - Panel de control
│   │   ├── games.tsx        # Gestión de juegos
│   │   ├── monitor.tsx      # Monitor de rendimiento
│   │   └── settings.tsx     # Configuración
│   └── _layout.tsx          # Layout principal
├── components/              # Componentes reutilizables
│   ├── GameCard.tsx        # Tarjeta de juego
│   ├── MetricCard.tsx      # Tarjeta de métrica
│   └── OptimizationButton.tsx # Botón de optimización
├── services/               # Servicios y lógica de negocio
│   ├── database.ts        # Servicio de Supabase
│   ├── shizuku.ts         # Integración de Shizuku
│   ├── optimization.ts    # Motor de optimizaciones
│   └── performance.ts     # Monitor de rendimiento
├── types/                 # Definiciones de tipos
│   ├── database.ts       # Tipos de la BD
│   └── env.d.ts         # Variables de entorno
└── lib/                  # Configuraciones
    └── supabase.ts      # Cliente de Supabase
```

## Uso de la Aplicación

### 1. Configurar Shizuku

Para usar todas las funcionalidades:

1. Descarga Shizuku desde [Google Play](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api)
2. Activa Shizuku mediante:
   - ADB Wireless (sin root)
   - Root (si tu dispositivo está rooteado)
3. Abre Game Booster y otorga permisos a Shizuku

### 2. Agregar Juegos

1. Ve a la pestaña "Juegos"
2. Toca el botón "+"
3. Ingresa el nombre del juego y su paquete (ej: com.dts.freefireth)
4. Configura el nivel de optimización
5. Activa las optimizaciones deseadas

### 3. Optimizar

- **Modo Automático**: Las optimizaciones se aplican cuando abres el juego
- **Modo Manual**: Toca un juego en la lista para aplicar optimizaciones
- **Boost Rápido**: Usa el botón en la pantalla principal

### 4. Monitorear

- Ve a la pestaña "Monitor" para ver métricas en tiempo real
- Observa FPS, CPU, GPU, RAM y temperatura
- Revisa gráficos históricos

## Niveles de Optimización

### Potato Mode
- Resolución reducida
- Sin sombras ni efectos
- Animaciones desactivadas
- Máximo ahorro de recursos
- Ideal para juegos muy pesados en dispositivos débiles

### Low
- Resolución normal
- Efectos mínimos
- Algunas optimizaciones activadas

### Medium (Predeterminado)
- Balance entre calidad y rendimiento
- Optimizaciones moderadas

### High
- Prioriza calidad visual
- Optimizaciones mínimas

### Ultra
- Máxima calidad
- Sin optimizaciones de gráficos
- Solo optimizaciones de sistema

## Base de Datos

La aplicación utiliza Supabase con tres tablas principales:

### game_profiles
Almacena configuraciones de optimización para cada juego.

### performance_history
Guarda métricas de rendimiento de sesiones de juego.

### app_settings
Preferencias del usuario y configuración global.

## Integración Completa de Shizuku

La versión actual incluye una implementación simulada de Shizuku. Para funcionalidad completa:

1. Exporta el proyecto: `npx expo prebuild`
2. Sigue las instrucciones en `SHIZUKU_INTEGRATION.md`
3. Implementa los módulos nativos de Android
4. Compila con Android Studio o EAS Build

## Comandos Disponibles

```bash
# Iniciar en modo desarrollo
npm run dev

# Compilar para web
npm run build:web

# Linter
npm run lint

# Type checking
npm run typecheck
```

## Limitaciones Actuales

Esta es una versión base que incluye:
- UI completa y funcional
- Sistema de perfiles de juegos
- Métricas simuladas en tiempo real
- Base de datos completamente funcional

Para funcionalidad completa necesitas:
- Exportar el proyecto a código nativo
- Integrar Shizuku (ver SHIZUKU_INTEGRATION.md)
- Implementar módulos nativos de Android
- Obtener permisos del sistema

## Advertencias

- Las optimizaciones agresivas pueden afectar la estabilidad del sistema
- La temperatura alta puede dañar el dispositivo
- Algunos juegos pueden detectar modificaciones
- Requiere Shizuku activo para funcionar completamente
- No funciona en iOS (solo Android)

## Próximas Funcionalidades

- Detección automática de juegos instalados
- Overlay de FPS sobre los juegos
- Perfiles comunitarios compartidos
- Optimizaciones por IA
- Grabación de sesiones de juego
- Estadísticas avanzadas

## Contribuir

Las contribuciones son bienvenidas. Por favor:
1. Haz fork del proyecto
2. Crea una rama para tu feature
3. Commit tus cambios
4. Push a la rama
5. Abre un Pull Request

## Licencia

MIT License

## Soporte

Para problemas o preguntas:
- Revisa la documentación de Shizuku
- Consulta SHIZUKU_INTEGRATION.md
- Abre un issue en GitHub

## Créditos

- Shizuku por Rikka Apps
- Expo Team
- Supabase Team
- Lucide Icons

---

Desarrollado con el objetivo de mejorar la experiencia de juego en dispositivos Android de gama baja.
