export type OptimizationLevel = 'potato' | 'low' | 'medium' | 'high' | 'ultra';

export interface GameProfile {
  id: string;
  package_name: string;
  game_name: string;
  icon_url?: string;
  optimization_level: OptimizationLevel;
  cpu_boost: boolean;
  ram_clear_before: boolean;
  block_notifications: boolean;
  reduce_animations: boolean;
  custom_resolution_scale: number;
  disable_shadows: boolean;
  disable_effects: boolean;
  auto_optimize: boolean;
  created_at: string;
  updated_at: string;
}

export interface PerformanceHistory {
  id: string;
  game_profile_id: string;
  session_start: string;
  session_end?: string;
  avg_fps?: number;
  min_fps?: number;
  max_fps?: number;
  avg_cpu_usage?: number;
  avg_gpu_usage?: number;
  avg_ram_usage?: number;
  avg_temperature?: number;
  optimization_level_used?: string;
  created_at: string;
}

export interface AppSettings {
  id: string;
  device_id: string;
  auto_detect_games: boolean;
  show_fps_overlay: boolean;
  show_performance_stats: boolean;
  temperature_warning_threshold: number;
  aggressive_optimization: boolean;
  created_at: string;
  updated_at: string;
}

export interface PerformanceMetrics {
  fps: number;
  cpu_usage: number;
  gpu_usage: number;
  ram_usage: number;
  temperature: number;
}
