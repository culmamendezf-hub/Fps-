import { supabase } from '@/lib/supabase';
import {
  GameProfile,
  PerformanceHistory,
  AppSettings,
  OptimizationLevel,
} from '@/types/database';

export const DatabaseService = {
  async getGameProfiles(): Promise<GameProfile[]> {
    const { data, error } = await supabase
      .from('game_profiles')
      .select('*')
      .order('game_name');

    if (error) throw error;
    return data || [];
  },

  async getGameProfile(packageName: string): Promise<GameProfile | null> {
    const { data, error } = await supabase
      .from('game_profiles')
      .select('*')
      .eq('package_name', packageName)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async createGameProfile(
    profile: Omit<GameProfile, 'id' | 'created_at' | 'updated_at'>
  ): Promise<GameProfile> {
    const { data, error } = await supabase
      .from('game_profiles')
      .insert(profile)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateGameProfile(
    id: string,
    updates: Partial<GameProfile>
  ): Promise<GameProfile> {
    const { data, error } = await supabase
      .from('game_profiles')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteGameProfile(id: string): Promise<void> {
    const { error } = await supabase
      .from('game_profiles')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async createPerformanceHistory(
    history: Omit<PerformanceHistory, 'id' | 'created_at'>
  ): Promise<PerformanceHistory> {
    const { data, error } = await supabase
      .from('performance_history')
      .insert(history)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updatePerformanceHistory(
    id: string,
    updates: Partial<PerformanceHistory>
  ): Promise<PerformanceHistory> {
    const { data, error } = await supabase
      .from('performance_history')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async getPerformanceHistory(
    gameProfileId: string,
    limit = 10
  ): Promise<PerformanceHistory[]> {
    const { data, error } = await supabase
      .from('performance_history')
      .select('*')
      .eq('game_profile_id', gameProfileId)
      .order('session_start', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data || [];
  },

  async getAppSettings(deviceId: string): Promise<AppSettings | null> {
    const { data, error } = await supabase
      .from('app_settings')
      .select('*')
      .eq('device_id', deviceId)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async createAppSettings(
    settings: Omit<AppSettings, 'id' | 'created_at' | 'updated_at'>
  ): Promise<AppSettings> {
    const { data, error } = await supabase
      .from('app_settings')
      .insert(settings)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateAppSettings(
    deviceId: string,
    updates: Partial<AppSettings>
  ): Promise<AppSettings> {
    const { data, error } = await supabase
      .from('app_settings')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('device_id', deviceId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },
};
