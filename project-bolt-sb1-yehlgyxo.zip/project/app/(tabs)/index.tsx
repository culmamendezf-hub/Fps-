import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {
  Zap,
  Cpu,
  Droplets,
  Bell,
  Trash2,
  Thermometer,
  Power,
} from 'lucide-react-native';
import MetricCard from '@/components/MetricCard';
import OptimizationButton from '@/components/OptimizationButton';
import { shizukuService } from '@/services/shizuku';
import { optimizationService } from '@/services/optimization';
import { performanceMonitor } from '@/services/performance';
import { PerformanceMetrics } from '@/types/database';

export default function HomeScreen() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    fps: 60,
    cpu_usage: 0,
    gpu_usage: 0,
    ram_usage: 0,
    temperature: 0,
  });
  const [isShizukuAvailable, setIsShizukuAvailable] = useState(false);
  const [optimizations, setOptimizations] = useState({
    cpuBoost: false,
    ramClear: false,
    notifications: false,
    animations: false,
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    checkShizuku();

    performanceMonitor.startMonitoring(1000);
    const unsubscribe = performanceMonitor.subscribe((newMetrics) => {
      setMetrics(newMetrics);
    });

    return () => {
      unsubscribe();
      performanceMonitor.stopMonitoring();
    };
  }, []);

  const checkShizuku = async () => {
    const available = await shizukuService.checkShizukuAvailability();
    setIsShizukuAvailable(available);

    if (!available) {
      Alert.alert(
        'Shizuku no disponible',
        'Para usar todas las funcionalidades, necesitas:\n\n1. Instalar Shizuku desde Google Play\n2. Activar Shizuku vía ADB o root\n3. Otorgar permisos a esta app\n\nLa app funcionará en modo limitado.'
      );
    }
  };

  const toggleOptimization = async (type: keyof typeof optimizations) => {
    setIsLoading(true);
    try {
      const newValue = !optimizations[type];
      setOptimizations((prev) => ({ ...prev, [type]: newValue }));

      switch (type) {
        case 'cpuBoost':
          await shizukuService.setCpuGovernor(
            newValue ? 'performance' : 'balanced'
          );
          break;
        case 'ramClear':
          if (newValue) {
            await optimizationService.quickRamBoost();
          }
          break;
        case 'notifications':
          await shizukuService.executeShellCommand(
            newValue ? 'cmd notification set_dnd on' : 'cmd notification set_dnd off'
          );
          break;
        case 'animations':
          await shizukuService.setAnimationScale(newValue ? 0 : 1);
          break;
      }
    } catch (error) {
      console.error('Error toggling optimization:', error);
      Alert.alert('Error', 'No se pudo aplicar la optimización');
      setOptimizations((prev) => ({ ...prev, [type]: !prev[type] }));
    } finally {
      setIsLoading(false);
    }
  };

  const quickBoost = async () => {
    setIsLoading(true);
    try {
      await optimizationService.quickRamBoost();
      await shizukuService.setCpuGovernor('performance');
      await shizukuService.setAnimationScale(0);

      setOptimizations({
        cpuBoost: true,
        ramClear: true,
        notifications: false,
        animations: true,
      });

      Alert.alert('Éxito', 'Optimización rápida aplicada');
    } catch (error) {
      console.error('Error applying quick boost:', error);
      Alert.alert('Error', 'No se pudo aplicar la optimización rápida');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Game Booster</Text>
            <Text style={styles.subtitle}>
              {isShizukuAvailable
                ? 'Sistema optimizado'
                : 'Modo limitado - Requiere Shizuku'}
            </Text>
          </View>
          <View
            style={[
              styles.statusBadge,
              { backgroundColor: isShizukuAvailable ? '#10b98120' : '#ef444420' },
            ]}>
            <Power
              size={16}
              color={isShizukuAvailable ? '#10b981' : '#ef4444'}
            />
            <Text
              style={[
                styles.statusText,
                { color: isShizukuAvailable ? '#10b981' : '#ef4444' },
              ]}>
              {isShizukuAvailable ? 'Activo' : 'Inactivo'}
            </Text>
          </View>
        </View>

        <View style={styles.metricsContainer}>
          <View style={styles.metricsRow}>
            <View style={styles.metricWrapper}>
              <MetricCard
                icon={Zap}
                label="FPS"
                value={metrics.fps}
                color="#10b981"
              />
            </View>
            <View style={styles.metricWrapper}>
              <MetricCard
                icon={Cpu}
                label="CPU"
                value={metrics.cpu_usage}
                unit="%"
                color="#3b82f6"
              />
            </View>
          </View>
          <View style={styles.metricsRow}>
            <View style={styles.metricWrapper}>
              <MetricCard
                icon={Droplets}
                label="RAM"
                value={Math.round(metrics.ram_usage)}
                unit="MB"
                color="#8b5cf6"
              />
            </View>
            <View style={styles.metricWrapper}>
              <MetricCard
                icon={Thermometer}
                label="Temp"
                value={metrics.temperature}
                unit="°C"
                color="#ef4444"
              />
            </View>
          </View>
        </View>

        <TouchableOpacity style={styles.quickBoostButton} onPress={quickBoost}>
          <Zap size={24} color="#fff" />
          <Text style={styles.quickBoostText}>Optimización Rápida</Text>
        </TouchableOpacity>

        <Text style={styles.sectionTitle}>Optimizaciones</Text>

        <View style={styles.optimizationsGrid}>
          <OptimizationButton
            icon={Cpu}
            label="Boost CPU"
            onPress={() => toggleOptimization('cpuBoost')}
            isActive={optimizations.cpuBoost}
            isLoading={isLoading}
            color="#3b82f6"
          />
          <OptimizationButton
            icon={Trash2}
            label="Limpiar RAM"
            onPress={() => toggleOptimization('ramClear')}
            isActive={optimizations.ramClear}
            isLoading={isLoading}
            color="#8b5cf6"
          />
          <OptimizationButton
            icon={Bell}
            label="Bloquear Notif."
            onPress={() => toggleOptimization('notifications')}
            isActive={optimizations.notifications}
            isLoading={isLoading}
            color="#f59e0b"
          />
          <OptimizationButton
            icon={Zap}
            label="Sin Animaciones"
            onPress={() => toggleOptimization('animations')}
            isActive={optimizations.animations}
            isLoading={isLoading}
            color="#10b981"
          />
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>Cómo usar</Text>
          <Text style={styles.infoText}>
            1. Activa Shizuku en tu dispositivo{'\n'}
            2. Otorga los permisos necesarios{'\n'}
            3. Configura tus juegos en la pestaña "Juegos"{'\n'}
            4. Las optimizaciones se aplicarán automáticamente
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
    paddingTop: 48,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#9ca3af',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  metricsContainer: {
    marginBottom: 20,
  },
  metricsRow: {
    flexDirection: 'row',
    marginBottom: 12,
    gap: 12,
  },
  metricWrapper: {
    flex: 1,
  },
  quickBoostButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
    gap: 8,
  },
  quickBoostText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 16,
  },
  optimizationsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -4,
    marginBottom: 24,
  },
  infoCard: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 12,
  },
  infoText: {
    fontSize: 14,
    color: '#9ca3af',
    lineHeight: 22,
  },
});
