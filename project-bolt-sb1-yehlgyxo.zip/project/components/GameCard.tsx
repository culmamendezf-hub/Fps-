import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Gamepad2, Settings, TrendingUp } from 'lucide-react-native';
import { GameProfile, OptimizationLevel } from '@/types/database';

interface GameCardProps {
  game: GameProfile;
  onPress: () => void;
  onConfigure: () => void;
}

const optimizationColors: Record<OptimizationLevel, string> = {
  potato: '#ef4444',
  low: '#f59e0b',
  medium: '#3b82f6',
  high: '#8b5cf6',
  ultra: '#10b981',
};

const optimizationLabels: Record<OptimizationLevel, string> = {
  potato: 'Potato',
  low: 'Bajo',
  medium: 'Medio',
  high: 'Alto',
  ultra: 'Ultra',
};

export default function GameCard({ game, onPress, onConfigure }: GameCardProps) {
  const levelColor = optimizationColors[game.optimization_level];
  const levelLabel = optimizationLabels[game.optimization_level];

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.iconContainer}>
        {game.icon_url ? (
          <Image source={{ uri: game.icon_url }} style={styles.icon} />
        ) : (
          <View style={styles.iconPlaceholder}>
            <Gamepad2 size={32} color="#9ca3af" />
          </View>
        )}
      </View>

      <View style={styles.content}>
        <Text style={styles.gameName} numberOfLines={1}>
          {game.game_name}
        </Text>
        <Text style={styles.packageName} numberOfLines={1}>
          {game.package_name}
        </Text>

        <View style={styles.features}>
          {game.cpu_boost && (
            <View style={styles.featureBadge}>
              <TrendingUp size={12} color="#10b981" />
              <Text style={styles.featureText}>CPU Boost</Text>
            </View>
          )}
          {game.ram_clear_before && (
            <View style={styles.featureBadge}>
              <Text style={styles.featureText}>RAM Clear</Text>
            </View>
          )}
        </View>
      </View>

      <View style={styles.actions}>
        <View
          style={[styles.levelBadge, { backgroundColor: levelColor + '20' }]}>
          <Text style={[styles.levelText, { color: levelColor }]}>
            {levelLabel}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.configButton}
          onPress={(e) => {
            e.stopPropagation();
            onConfigure();
          }}>
          <Settings size={20} color="#9ca3af" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#374151',
  },
  iconContainer: {
    marginRight: 12,
  },
  icon: {
    width: 56,
    height: 56,
    borderRadius: 12,
  },
  iconPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: '#374151',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  gameName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 4,
  },
  packageName: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 8,
  },
  features: {
    flexDirection: 'row',
    gap: 6,
  },
  featureBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#374151',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    gap: 4,
  },
  featureText: {
    fontSize: 10,
    color: '#9ca3af',
    fontWeight: '600',
  },
  actions: {
    alignItems: 'flex-end',
    gap: 8,
  },
  levelBadge: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  levelText: {
    fontSize: 12,
    fontWeight: '700',
  },
  configButton: {
    padding: 8,
  },
});
