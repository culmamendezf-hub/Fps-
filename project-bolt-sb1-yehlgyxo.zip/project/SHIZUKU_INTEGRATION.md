# Integración de Shizuku - Game Booster

Esta guía te ayudará a integrar completamente Shizuku en la aplicación Game Booster.

## Requisitos Previos

1. Android Studio instalado
2. Conocimientos básicos de desarrollo nativo de Android
3. Dispositivo Android con Shizuku instalado y funcionando

## Paso 1: Exportar el Proyecto Expo

```bash
npx expo prebuild
```

Este comando generará las carpetas `android/` e `ios/` con código nativo.

## Paso 2: Agregar Dependencias de Shizuku

Agrega las siguientes dependencias en `android/app/build.gradle`:

```gradle
dependencies {
    // Shizuku
    implementation 'dev.rikka.shizuku:api:13.1.5'
    implementation 'dev.rikka.shizuku:provider:13.1.5'

    // Otras dependencias existentes...
}
```

## Paso 3: Configurar Permisos en AndroidManifest.xml

Agrega los siguientes permisos en `android/app/src/main/AndroidManifest.xml`:

```xml
<manifest>
    <!-- Permisos de Shizuku -->
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
    <uses-permission android:name="moe.shizuku.manager.permission.API_V23" />

    <!-- Permisos para optimizaciones -->
    <uses-permission android:name="android.permission.WRITE_SETTINGS" />
    <uses-permission android:name="android.permission.WRITE_SECURE_SETTINGS" />
    <uses-permission android:name="android.permission.CHANGE_CONFIGURATION" />
    <uses-permission android:name="android.permission.MODIFY_PHONE_STATE" />
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <application>
        <!-- Proveedor de Shizuku -->
        <provider
            android:name="moe.shizuku.api.ShizukuProvider"
            android:authorities="${applicationId}.shizuku"
            android:enabled="true"
            android:exported="true"
            android:multiprocess="false"
            android:permission="android.permission.INTERACT_ACROSS_USERS_FULL" />
    </application>
</manifest>
```

## Paso 4: Crear el Módulo Nativo de Shizuku

Crea el archivo `android/app/src/main/java/com/yourapp/ShizukuModule.java`:

```java
package com.yourapp;

import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import moe.shizuku.api.ShizukuBinderWrapper;
import moe.shizuku.api.ShizukuProvider;
import moe.shizuku.api.SystemServiceHelper;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ShizukuModule extends ReactContextBaseJavaModule {
    private static final String MODULE_NAME = "ShizukuModule";

    public ShizukuModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @NonNull
    @Override
    public String getName() {
        return MODULE_NAME;
    }

    @ReactMethod
    public void checkAvailability(Promise promise) {
        try {
            boolean available = ShizukuProvider.isShizukuAvailable();
            promise.resolve(available);
        } catch (Exception e) {
            promise.reject("ERROR", e.getMessage());
        }
    }

    @ReactMethod
    public void requestPermission(Promise promise) {
        try {
            if (ShizukuProvider.checkSelfPermission() == 0) {
                promise.resolve(true);
            } else {
                ShizukuProvider.requestPermission(0);
                promise.resolve(false);
            }
        } catch (Exception e) {
            promise.reject("ERROR", e.getMessage());
        }
    }

    @ReactMethod
    public void executeCommand(String command, Promise promise) {
        try {
            if (ShizukuProvider.checkSelfPermission() != 0) {
                promise.reject("PERMISSION_DENIED", "Shizuku permission not granted");
                return;
            }

            Process process = ShizukuProvider.getService()
                .newProcess(new String[]{"sh", "-c", command}, null, null);

            BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream())
            );

            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            int exitCode = process.waitFor();
            if (exitCode == 0) {
                promise.resolve(output.toString());
            } else {
                promise.reject("COMMAND_FAILED", "Exit code: " + exitCode);
            }
        } catch (Exception e) {
            promise.reject("ERROR", e.getMessage());
        }
    }
}
```

## Paso 5: Registrar el Módulo

Crea `android/app/src/main/java/com/yourapp/ShizukuPackage.java`:

```java
package com.yourapp;

import androidx.annotation.NonNull;
import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShizukuPackage implements ReactPackage {
    @NonNull
    @Override
    public List<NativeModule> createNativeModules(@NonNull ReactApplicationContext reactContext) {
        List<NativeModule> modules = new ArrayList<>();
        modules.add(new ShizukuModule(reactContext));
        return modules;
    }

    @NonNull
    @Override
    public List<ViewManager> createViewManagers(@NonNull ReactApplicationContext reactContext) {
        return Collections.emptyList();
    }
}
```

Luego registra el paquete en `MainApplication.java`:

```java
@Override
protected List<ReactPackage> getPackages() {
    List<ReactPackage> packages = new PackageList(this).getPackages();
    packages.add(new ShizukuPackage()); // Agregar esta línea
    return packages;
}
```

## Paso 6: Crear el Puente JavaScript

Crea `services/shizukuNative.ts`:

```typescript
import { NativeModules, Platform } from 'react-native';

const { ShizukuModule } = NativeModules;

export const ShizukuNative = {
  async checkAvailability(): Promise<boolean> {
    if (Platform.OS !== 'android') return false;
    try {
      return await ShizukuModule.checkAvailability();
    } catch (error) {
      console.error('Error checking Shizuku:', error);
      return false;
    }
  },

  async requestPermission(): Promise<boolean> {
    if (Platform.OS !== 'android') return false;
    try {
      return await ShizukuModule.requestPermission();
    } catch (error) {
      console.error('Error requesting permission:', error);
      return false;
    }
  },

  async executeCommand(command: string): Promise<string> {
    if (Platform.OS !== 'android') {
      throw new Error('Platform not supported');
    }
    try {
      return await ShizukuModule.executeCommand(command);
    } catch (error) {
      console.error('Error executing command:', error);
      throw error;
    }
  },
};
```

## Paso 7: Actualizar el Servicio de Shizuku

Reemplaza el contenido de `services/shizuku.ts` para usar el módulo nativo:

```typescript
import { Platform } from 'react-native';
import { ShizukuNative } from './shizukuNative';

export class ShizukuService {
  private static instance: ShizukuService;
  private isShizukuAvailable = false;
  private isPermissionGranted = false;

  private constructor() {}

  static getInstance(): ShizukuService {
    if (!ShizukuService.instance) {
      ShizukuService.instance = new ShizukuService();
    }
    return ShizukuService.instance;
  }

  async checkShizukuAvailability(): Promise<boolean> {
    if (Platform.OS !== 'android') {
      return false;
    }

    try {
      this.isShizukuAvailable = await ShizukuNative.checkAvailability();
      return this.isShizukuAvailable;
    } catch (error) {
      console.error('Error checking Shizuku availability:', error);
      return false;
    }
  }

  async requestShizukuPermission(): Promise<boolean> {
    if (Platform.OS !== 'android') {
      return false;
    }

    try {
      this.isPermissionGranted = await ShizukuNative.requestPermission();
      return this.isPermissionGranted;
    } catch (error) {
      console.error('Error requesting Shizuku permission:', error);
      return false;
    }
  }

  async executeShellCommand(command: string): Promise<string> {
    if (Platform.OS !== 'android') {
      return 'Platform not supported';
    }

    if (!this.isShizukuAvailable || !this.isPermissionGranted) {
      throw new Error('Shizuku not available or permission not granted');
    }

    try {
      return await ShizukuNative.executeCommand(command);
    } catch (error) {
      console.error('Error executing shell command:', error);
      throw error;
    }
  }

  // El resto de los métodos permanecen igual...
}

export const shizukuService = ShizukuService.getInstance();
```

## Paso 8: Monitoreo de Rendimiento Real

Para obtener métricas reales del sistema, necesitarás crear un módulo nativo adicional que lea:

- `/proc/stat` para uso de CPU
- `/sys/class/thermal/thermal_zone*/temp` para temperatura
- `ActivityManager.MemoryInfo` para RAM
- Implementar un contador de FPS usando Choreographer

Ejemplo básico en `PerformanceModule.java`:

```java
import android.app.ActivityManager;
import android.content.Context;
import android.view.Choreographer;

@ReactMethod
public void getSystemMetrics(Promise promise) {
    try {
        ActivityManager activityManager =
            (ActivityManager) getReactApplicationContext()
                .getSystemService(Context.ACTIVITY_SERVICE);

        ActivityManager.MemoryInfo memoryInfo =
            new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        WritableMap metrics = Arguments.createMap();
        metrics.putDouble("ramUsage",
            (memoryInfo.totalMem - memoryInfo.availMem) / 1024.0 / 1024.0);
        metrics.putDouble("cpuUsage", getCpuUsage());
        metrics.putDouble("temperature", getTemperature());

        promise.resolve(metrics);
    } catch (Exception e) {
        promise.reject("ERROR", e.getMessage());
    }
}
```

## Paso 9: Detección de Juegos

Para detectar cuándo se abre un juego, implementa un servicio en segundo plano que monitoree las apps activas usando `UsageStatsManager`.

## Paso 10: Compilar y Probar

```bash
# Compilar la aplicación
cd android
./gradlew assembleRelease

# O usar Expo
npx expo run:android
```

## Notas Importantes

1. **Shizuku debe estar activo**: El usuario debe tener Shizuku instalado y activo antes de usar la app
2. **Permisos ADB**: Algunos comandos requieren permisos especiales que solo Shizuku puede otorgar
3. **Root no requerido**: Shizuku funciona sin root usando ADB wireless
4. **Batería**: Las optimizaciones agresivas pueden afectar la duración de la batería
5. **Seguridad**: Valida todos los comandos antes de ejecutarlos para evitar inyección de código

## Recursos Adicionales

- [Documentación oficial de Shizuku](https://shizuku.rikka.app/)
- [Shizuku API en GitHub](https://github.com/RikkaApps/Shizuku-API)
- [Ejemplos de integración](https://github.com/RikkaApps/Shizuku-API/tree/master/sample)

## Soporte

Para problemas con la integración de Shizuku, consulta:
- [Issues de Shizuku](https://github.com/RikkaApps/Shizuku/issues)
- [Telegram de Shizuku](https://t.me/ShizukuGroup)
