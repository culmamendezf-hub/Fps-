-- Game Optimizer Database Schema
--
-- 1. New Tables
--    - game_profiles: Stores optimization profiles for each game
--    - performance_history: Tracks gaming session performance metrics
--    - app_settings: User preferences and app configuration
--
-- 2. Security
--    - Enable RLS on all tables
--    - Public read access for game_profiles (for sharing profiles)
--    - Device-specific access for performance_history and app_settings

-- Create game_profiles table
CREATE TABLE IF NOT EXISTS game_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_name text UNIQUE NOT NULL,
  game_name text NOT NULL,
  icon_url text,
  optimization_level text NOT NULL DEFAULT 'medium',
  cpu_boost boolean DEFAULT false,
  ram_clear_before boolean DEFAULT true,
  block_notifications boolean DEFAULT true,
  reduce_animations boolean DEFAULT false,
  custom_resolution_scale numeric DEFAULT 1.0,
  disable_shadows boolean DEFAULT false,
  disable_effects boolean DEFAULT false,
  auto_optimize boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create performance_history table
CREATE TABLE IF NOT EXISTS performance_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_profile_id uuid REFERENCES game_profiles(id) ON DELETE CASCADE,
  session_start timestamptz NOT NULL,
  session_end timestamptz,
  avg_fps numeric,
  min_fps numeric,
  max_fps numeric,
  avg_cpu_usage numeric,
  avg_gpu_usage numeric,
  avg_ram_usage numeric,
  avg_temperature numeric,
  optimization_level_used text,
  created_at timestamptz DEFAULT now()
);

-- Create app_settings table
CREATE TABLE IF NOT EXISTS app_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text UNIQUE NOT NULL,
  auto_detect_games boolean DEFAULT true,
  show_fps_overlay boolean DEFAULT true,
  show_performance_stats boolean DEFAULT true,
  temperature_warning_threshold numeric DEFAULT 45.0,
  aggressive_optimization boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE game_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

-- Policies for game_profiles (public read, anyone can create/update)
CREATE POLICY "Anyone can view game profiles"
  ON game_profiles FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can create game profiles"
  ON game_profiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update game profiles"
  ON game_profiles FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete game profiles"
  ON game_profiles FOR DELETE
  TO anon, authenticated
  USING (true);

-- Policies for performance_history (public access for analytics)
CREATE POLICY "Anyone can view performance history"
  ON performance_history FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can create performance history"
  ON performance_history FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Policies for app_settings (device-specific)
CREATE POLICY "Anyone can view their settings"
  ON app_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can create their settings"
  ON app_settings FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update their settings"
  ON app_settings FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_game_profiles_package_name ON game_profiles(package_name);
CREATE INDEX IF NOT EXISTS idx_performance_history_game_profile_id ON performance_history(game_profile_id);
CREATE INDEX IF NOT EXISTS idx_performance_history_session_start ON performance_history(session_start);
CREATE INDEX IF NOT EXISTS idx_app_settings_device_id ON app_settings(device_id);