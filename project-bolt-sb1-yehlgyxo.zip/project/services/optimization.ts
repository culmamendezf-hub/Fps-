import { Platform } from 'react-native';
import { shizukuService } from './shizuku';
import { GameProfile, OptimizationLevel } from '@/types/database';

export class OptimizationService {
  private static instance: OptimizationService;
  private currentOptimizationLevel: OptimizationLevel = 'medium';
  private isOptimizing = false;

  private constructor() {}

  static getInstance(): OptimizationService {
    if (!OptimizationService.instance) {
      OptimizationService.instance = new OptimizationService();
    }
    return OptimizationService.instance;
  }

  async applyOptimizations(profile: GameProfile): Promise<void> {
    if (Platform.OS !== 'android') {
      console.log('Optimizations only available on Android');
      return;
    }

    if (this.isOptimizing) {
      console.log('Optimization already in progress');
      return;
    }

    this.isOptimizing = true;
    this.currentOptimizationLevel = profile.optimization_level;

    try {
      if (profile.ram_clear_before) {
        await this.clearRam();
      }

      if (profile.reduce_animations) {
        await this.setAnimations(0);
      }

      if (profile.cpu_boost) {
        await this.setCpuPerformanceMode();
      }

      if (profile.block_notifications) {
        await this.blockNotifications(true);
      }

      await this.applyGraphicsOptimizations(profile);

      await shizukuService.optimizeForGame(profile.package_name);
      await shizukuService.setAppPriority(profile.package_name, 'high');
    } catch (error) {
      console.error('Error applying optimizations:', error);
      throw error;
    } finally {
      this.isOptimizing = false;
    }
  }

  async revertOptimizations(): Promise<void> {
    if (Platform.OS !== 'android') {
      return;
    }

    try {
      await this.setAnimations(1);
      await shizukuService.setCpuGovernor('balanced');
      await this.blockNotifications(false);
    } catch (error) {
      console.error('Error reverting optimizations:', error);
    }

    this.currentOptimizationLevel = 'medium';
  }

  private async clearRam(): Promise<void> {
    try {
      await shizukuService.clearRamCache();
      await shizukuService.killBackgroundProcesses();
    } catch (error) {
      console.error('Error clearing RAM:', error);
    }
  }

  private async setAnimations(scale: number): Promise<void> {
    try {
      await shizukuService.setAnimationScale(scale);
    } catch (error) {
      console.error('Error setting animations:', error);
    }
  }

  private async setCpuPerformanceMode(): Promise<void> {
    try {
      await shizukuService.setCpuGovernor('performance');
      await shizukuService.setGpuTurboMode(true);
    } catch (error) {
      console.error('Error setting CPU performance mode:', error);
    }
  }

  private async blockNotifications(block: boolean): Promise<void> {
    try {
      const cmd = block
        ? 'cmd notification set_dnd on'
        : 'cmd notification set_dnd off';
      await shizukuService.executeShellCommand(cmd);
    } catch (error) {
      console.error('Error toggling notifications:', error);
    }
  }

  private async applyGraphicsOptimizations(profile: GameProfile): Promise<void> {
    const commands: string[] = [];

    switch (profile.optimization_level) {
      case 'potato':
        commands.push('setprop debug.hwui.render_dirty_regions false');
        commands.push('setprop debug.egl.hw 0');
        commands.push('setprop ro.config.low_ram true');
        break;
      case 'low':
        commands.push('setprop debug.hwui.render_dirty_regions true');
        commands.push('setprop debug.egl.hw 1');
        break;
      case 'high':
      case 'ultra':
        commands.push('setprop debug.hwui.renderer skiagl');
        commands.push('setprop debug.renderengine.backend skiaglthreaded');
        break;
    }

    if (profile.disable_shadows) {
      commands.push('setprop debug.hwui.use_buffer_age false');
    }

    if (profile.custom_resolution_scale < 1.0) {
      const scale = Math.round(profile.custom_resolution_scale * 100);
      commands.push(`wm density ${scale}`);
    }

    for (const cmd of commands) {
      try {
        await shizukuService.executeShellCommand(cmd);
      } catch (error) {
        console.error('Error applying graphics optimization:', cmd, error);
      }
    }
  }

  async quickRamBoost(): Promise<void> {
    await this.clearRam();
  }

  getCurrentOptimizationLevel(): OptimizationLevel {
    return this.currentOptimizationLevel;
  }

  isCurrentlyOptimizing(): boolean {
    return this.isOptimizing;
  }
}

export const optimizationService = OptimizationService.getInstance();
