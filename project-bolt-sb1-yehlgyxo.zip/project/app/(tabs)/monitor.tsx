import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import {
  Zap,
  Cpu,
  Droplets,
  Thermometer,
  TrendingUp,
  TrendingDown,
  Minus,
} from 'lucide-react-native';
import { performanceMonitor } from '@/services/performance';
import { PerformanceMetrics } from '@/types/database';

const SCREEN_WIDTH = Dimensions.get('window').width;
const CHART_POINTS = 30;

export default function MonitorScreen() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    fps: 60,
    cpu_usage: 0,
    gpu_usage: 0,
    ram_usage: 0,
    temperature: 0,
  });

  const [fpsHistory, setFpsHistory] = useState<number[]>(
    Array(CHART_POINTS).fill(60)
  );
  const [cpuHistory, setCpuHistory] = useState<number[]>(
    Array(CHART_POINTS).fill(0)
  );

  useEffect(() => {
    performanceMonitor.startMonitoring(1000);
    const unsubscribe = performanceMonitor.subscribe((newMetrics) => {
      setMetrics(newMetrics);
      setFpsHistory((prev) => [...prev.slice(1), newMetrics.fps]);
      setCpuHistory((prev) => [...prev.slice(1), newMetrics.cpu_usage]);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const getTrend = (current: number, previous: number) => {
    if (current > previous + 2) return 'up';
    if (current < previous - 2) return 'down';
    return 'stable';
  };

  const fpsTrend = getTrend(
    fpsHistory[fpsHistory.length - 1],
    fpsHistory[fpsHistory.length - 2]
  );
  const cpuTrend = getTrend(
    cpuHistory[cpuHistory.length - 1],
    cpuHistory[cpuHistory.length - 2]
  );

  const TrendIcon = (trend: string) => {
    if (trend === 'up')
      return <TrendingUp size={16} color="#10b981" />;
    if (trend === 'down')
      return <TrendingDown size={16} color="#ef4444" />;
    return <Minus size={16} color="#6b7280" />;
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Monitor de Rendimiento</Text>
          <Text style={styles.subtitle}>Métricas en tiempo real</Text>
        </View>

        <View style={styles.mainMetric}>
          <View style={styles.mainMetricHeader}>
            <Zap size={32} color="#10b981" />
            <Text style={styles.mainMetricLabel}>FPS</Text>
          </View>
          <View style={styles.mainMetricValue}>
            <Text style={styles.mainMetricNumber}>{metrics.fps}</Text>
            {TrendIcon(fpsTrend)}
          </View>
          <View style={styles.chart}>
            {fpsHistory.map((value, index) => {
              const height = (value / 60) * 100;
              const color =
                value >= 50 ? '#10b981' : value >= 30 ? '#f59e0b' : '#ef4444';
              return (
                <View
                  key={index}
                  style={[
                    styles.chartBar,
                    { height: `${height}%`, backgroundColor: color },
                  ]}
                />
              );
            })}
          </View>
          <View style={styles.chartLabels}>
            <Text style={styles.chartLabel}>0</Text>
            <Text style={styles.chartLabel}>30</Text>
            <Text style={styles.chartLabel}>60</Text>
          </View>
        </View>

        <View style={styles.metricsGrid}>
          <View style={styles.metricCard}>
            <View style={styles.metricHeader}>
              <Cpu size={24} color="#3b82f6" />
              <Text style={styles.metricLabel}>CPU</Text>
            </View>
            <View style={styles.metricValueContainer}>
              <Text style={styles.metricValue}>{metrics.cpu_usage}%</Text>
              {TrendIcon(cpuTrend)}
            </View>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${metrics.cpu_usage}%`,
                    backgroundColor: '#3b82f6',
                  },
                ]}
              />
            </View>
          </View>

          <View style={styles.metricCard}>
            <View style={styles.metricHeader}>
              <Cpu size={24} color="#8b5cf6" />
              <Text style={styles.metricLabel}>GPU</Text>
            </View>
            <View style={styles.metricValueContainer}>
              <Text style={styles.metricValue}>{metrics.gpu_usage}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${metrics.gpu_usage}%`,
                    backgroundColor: '#8b5cf6',
                  },
                ]}
              />
            </View>
          </View>

          <View style={styles.metricCard}>
            <View style={styles.metricHeader}>
              <Droplets size={24} color="#06b6d4" />
              <Text style={styles.metricLabel}>RAM</Text>
            </View>
            <View style={styles.metricValueContainer}>
              <Text style={styles.metricValue}>
                {Math.round(metrics.ram_usage)} MB
              </Text>
            </View>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${(metrics.ram_usage / 4096) * 100}%`,
                    backgroundColor: '#06b6d4',
                  },
                ]}
              />
            </View>
          </View>

          <View style={styles.metricCard}>
            <View style={styles.metricHeader}>
              <Thermometer size={24} color="#ef4444" />
              <Text style={styles.metricLabel}>Temperatura</Text>
            </View>
            <View style={styles.metricValueContainer}>
              <Text style={styles.metricValue}>{metrics.temperature}°C</Text>
            </View>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${(metrics.temperature / 60) * 100}%`,
                    backgroundColor:
                      metrics.temperature > 45 ? '#ef4444' : '#f59e0b',
                  },
                ]}
              />
            </View>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>Sobre las métricas</Text>
          <View style={styles.infoRow}>
            <View style={[styles.infoDot, { backgroundColor: '#10b981' }]} />
            <Text style={styles.infoText}>
              FPS: 60+ es óptimo, 30-59 aceptable, menos de 30 bajo
            </Text>
          </View>
          <View style={styles.infoRow}>
            <View style={[styles.infoDot, { backgroundColor: '#3b82f6' }]} />
            <Text style={styles.infoText}>
              CPU/GPU: Menos de 70% es ideal para evitar sobrecalentamiento
            </Text>
          </View>
          <View style={styles.infoRow}>
            <View style={[styles.infoDot, { backgroundColor: '#ef4444' }]} />
            <Text style={styles.infoText}>
              Temperatura: Más de 45°C puede afectar el rendimiento
            </Text>
          </View>
        </View>

        <View style={styles.noteCard}>
          <Text style={styles.noteText}>
            Nota: Estas métricas son estimaciones simuladas. Para métricas
            reales, se requiere integración nativa completa de Shizuku.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
    paddingTop: 48,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#9ca3af',
  },
  mainMetric: {
    backgroundColor: '#1f2937',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  mainMetricHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  mainMetricLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: '#9ca3af',
  },
  mainMetricValue: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 12,
  },
  mainMetricNumber: {
    fontSize: 48,
    fontWeight: '700',
    color: '#f9fafb',
  },
  chart: {
    flexDirection: 'row',
    height: 100,
    alignItems: 'flex-end',
    gap: 2,
    marginBottom: 8,
  },
  chartBar: {
    flex: 1,
    borderRadius: 2,
    minHeight: 2,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  chartLabel: {
    fontSize: 12,
    color: '#6b7280',
  },
  metricsGrid: {
    gap: 12,
    marginBottom: 16,
  },
  metricCard: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  metricHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  metricLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#9ca3af',
  },
  metricValueContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#f9fafb',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#374151',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  infoCard: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#374151',
    marginBottom: 12,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  infoDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  infoText: {
    fontSize: 14,
    color: '#9ca3af',
    flex: 1,
  },
  noteCard: {
    backgroundColor: '#1f293780',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#374151',
    borderStyle: 'dashed',
  },
  noteText: {
    fontSize: 13,
    color: '#9ca3af',
    fontStyle: 'italic',
    lineHeight: 20,
  },
});
