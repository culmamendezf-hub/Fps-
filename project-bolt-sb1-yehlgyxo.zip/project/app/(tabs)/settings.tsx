import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Linking,
} from 'react-native';
import Constants from 'expo-constants';
import {
  Settings as SettingsIcon,
  Trash2,
  Thermometer,
  Bell,
  Eye,
  Zap,
  Info,
  ExternalLink,
  RefreshCw,
  Shield,
} from 'lucide-react-native';
import { shizukuService } from '@/services/shizuku';
import { optimizationService } from '@/services/optimization';
import { DatabaseService } from '@/services/database';

export default function SettingsScreen() {
  const [deviceId] = useState(
    Constants.deviceId || 'unknown-' + Date.now()
  );
  const [settings, setSettings] = useState({
    auto_detect_games: true,
    show_fps_overlay: true,
    show_performance_stats: true,
    temperature_warning_threshold: 45.0,
    aggressive_optimization: false,
  });
  const [isShizukuAvailable, setIsShizukuAvailable] = useState(false);

  useEffect(() => {
    loadSettings();
    checkShizuku();
  }, []);

  const loadSettings = async () => {
    try {
      const savedSettings = await DatabaseService.getAppSettings(deviceId);
      if (savedSettings) {
        setSettings({
          auto_detect_games: savedSettings.auto_detect_games,
          show_fps_overlay: savedSettings.show_fps_overlay,
          show_performance_stats: savedSettings.show_performance_stats,
          temperature_warning_threshold:
            savedSettings.temperature_warning_threshold,
          aggressive_optimization: savedSettings.aggressive_optimization,
        });
      } else {
        await DatabaseService.createAppSettings({
          device_id: deviceId,
          ...settings,
        });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const updateSetting = async (
    key: keyof typeof settings,
    value: boolean | number
  ) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);

    try {
      await DatabaseService.updateAppSettings(deviceId, newSettings);
    } catch (error) {
      console.error('Error updating settings:', error);
    }
  };

  const checkShizuku = async () => {
    const available = await shizukuService.checkShizukuAvailability();
    setIsShizukuAvailable(available);
  };

  const clearRamNow = async () => {
    try {
      await optimizationService.quickRamBoost();
      Alert.alert('Éxito', 'RAM limpiada correctamente');
    } catch (error) {
      Alert.alert('Error', 'No se pudo limpiar la RAM');
    }
  };

  const resetAllOptimizations = async () => {
    Alert.alert(
      'Confirmar',
      '¿Restaurar todas las optimizaciones a sus valores por defecto?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Restaurar',
          onPress: async () => {
            try {
              await optimizationService.revertOptimizations();
              Alert.alert('Éxito', 'Optimizaciones restauradas');
            } catch (error) {
              Alert.alert('Error', 'No se pudo restaurar');
            }
          },
        },
      ]
    );
  };

  const openShizukuDownload = () => {
    Linking.openURL('https://shizuku.rikka.app/download/');
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Configuración</Text>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Shield size={20} color="#10b981" />
            <Text style={styles.sectionTitle}>Shizuku</Text>
          </View>

          <View style={styles.card}>
            <View style={styles.cardRow}>
              <View>
                <Text style={styles.cardLabel}>Estado de Shizuku</Text>
                <Text style={styles.cardSubtext}>
                  {isShizukuAvailable
                    ? 'Conectado y funcionando'
                    : 'No disponible'}
                </Text>
              </View>
              <View
                style={[
                  styles.statusIndicator,
                  {
                    backgroundColor: isShizukuAvailable
                      ? '#10b981'
                      : '#ef4444',
                  },
                ]}
              />
            </View>

            {!isShizukuAvailable && (
              <TouchableOpacity
                style={styles.linkButton}
                onPress={openShizukuDownload}>
                <ExternalLink size={16} color="#10b981" />
                <Text style={styles.linkButtonText}>Descargar Shizuku</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Zap size={20} color="#10b981" />
            <Text style={styles.sectionTitle}>Herramientas Rápidas</Text>
          </View>

          <View style={styles.toolsGrid}>
            <TouchableOpacity style={styles.toolButton} onPress={clearRamNow}>
              <Trash2 size={28} color="#8b5cf6" />
              <Text style={styles.toolButtonText}>Limpiar RAM</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.toolButton}
              onPress={resetAllOptimizations}>
              <RefreshCw size={28} color="#3b82f6" />
              <Text style={styles.toolButtonText}>Restaurar</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <SettingsIcon size={20} color="#10b981" />
            <Text style={styles.sectionTitle}>Preferencias</Text>
          </View>

          <View style={styles.card}>
            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingLabel}>
                  Auto-detectar juegos
                </Text>
                <Text style={styles.settingSubtext}>
                  Aplicar optimizaciones automáticamente
                </Text>
              </View>
              <Switch
                value={settings.auto_detect_games}
                onValueChange={(value) =>
                  updateSetting('auto_detect_games', value)
                }
                trackColor={{ false: '#374151', true: '#10b981' }}
                thumbColor="#fff"
              />
            </View>

            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Eye size={20} color="#9ca3af" />
                <View style={styles.settingText}>
                  <Text style={styles.settingLabel}>Mostrar FPS</Text>
                  <Text style={styles.settingSubtext}>
                    Overlay de FPS en juegos
                  </Text>
                </View>
              </View>
              <Switch
                value={settings.show_fps_overlay}
                onValueChange={(value) =>
                  updateSetting('show_fps_overlay', value)
                }
                trackColor={{ false: '#374151', true: '#10b981' }}
                thumbColor="#fff"
              />
            </View>

            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Zap size={20} color="#9ca3af" />
                <View style={styles.settingText}>
                  <Text style={styles.settingLabel}>Estadísticas</Text>
                  <Text style={styles.settingSubtext}>
                    Mostrar métricas de rendimiento
                  </Text>
                </View>
              </View>
              <Switch
                value={settings.show_performance_stats}
                onValueChange={(value) =>
                  updateSetting('show_performance_stats', value)
                }
                trackColor={{ false: '#374151', true: '#10b981' }}
                thumbColor="#fff"
              />
            </View>

            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Thermometer size={20} color="#9ca3af" />
                <View style={styles.settingText}>
                  <Text style={styles.settingLabel}>
                    Alerta de temperatura
                  </Text>
                  <Text style={styles.settingSubtext}>
                    Umbral: {settings.temperature_warning_threshold}°C
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Bell size={20} color="#9ca3af" />
                <View style={styles.settingText}>
                  <Text style={styles.settingLabel}>
                    Optimización agresiva
                  </Text>
                  <Text style={styles.settingSubtext}>
                    Máximo rendimiento, menor duración de batería
                  </Text>
                </View>
              </View>
              <Switch
                value={settings.aggressive_optimization}
                onValueChange={(value) =>
                  updateSetting('aggressive_optimization', value)
                }
                trackColor={{ false: '#374151', true: '#10b981' }}
                thumbColor="#fff"
              />
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Info size={20} color="#10b981" />
            <Text style={styles.sectionTitle}>Información</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Game Booster v1.0</Text>
            <Text style={styles.infoText}>
              Optimizador de rendimiento para juegos en dispositivos Android de
              gama baja.
            </Text>
            <View style={styles.divider} />
            <Text style={styles.infoLabel}>Funcionalidades:</Text>
            <Text style={styles.infoText}>
              • Optimización automática de juegos{'\n'}
              • Modo Potato para máximo rendimiento{'\n'}
              • Monitoreo de FPS en tiempo real{'\n'}
              • Limpieza de RAM automática{'\n'}
              • Control de CPU y GPU{'\n'}
              • Perfiles personalizados por juego
            </Text>
            <View style={styles.divider} />
            <Text style={styles.noteText}>
              Nota: Esta app requiere Shizuku para funcionar completamente.
              Algunas funciones están simuladas en este entorno de desarrollo.
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.warningCard}>
            <Text style={styles.warningTitle}>Importante</Text>
            <Text style={styles.warningText}>
              Para usar todas las funcionalidades:{'\n\n'}
              1. Instala Shizuku desde Google Play{'\n'}
              2. Activa Shizuku vía ADB o root{'\n'}
              3. Otorga permisos a esta app{'\n'}
              4. Exporta el proyecto y agrega los módulos nativos
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
    paddingTop: 48,
    paddingBottom: 32,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#f9fafb',
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f9fafb',
  },
  card: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  cardRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f9fafb',
    marginBottom: 4,
  },
  cardSubtext: {
    fontSize: 13,
    color: '#9ca3af',
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  linkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#374151',
    gap: 8,
  },
  linkButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#10b981',
  },
  toolsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  toolButton: {
    flex: 1,
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#374151',
    gap: 8,
  },
  toolButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f9fafb',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  settingText: {
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f9fafb',
    marginBottom: 2,
  },
  settingSubtext: {
    fontSize: 13,
    color: '#9ca3af',
  },
  infoCard: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 8,
  },
  infoLabel: {
    fontSize: 14,
    fontWeight: '700',
    color: '#f9fafb',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#9ca3af',
    lineHeight: 22,
  },
  noteText: {
    fontSize: 13,
    color: '#9ca3af',
    fontStyle: 'italic',
    lineHeight: 20,
  },
  divider: {
    height: 1,
    backgroundColor: '#374151',
    marginVertical: 12,
  },
  warningCard: {
    backgroundColor: '#7c2d1220',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#f59e0b',
  },
  warningTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#f59e0b',
    marginBottom: 8,
  },
  warningText: {
    fontSize: 14,
    color: '#fbbf24',
    lineHeight: 22,
  },
});
