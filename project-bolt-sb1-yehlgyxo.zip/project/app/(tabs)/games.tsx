import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
  Switch,
} from 'react-native';
import { Plus, Search, X } from 'lucide-react-native';
import GameCard from '@/components/GameCard';
import { DatabaseService } from '@/services/database';
import { GameProfile, OptimizationLevel } from '@/types/database';
import { optimizationService } from '@/services/optimization';

const optimizationLevels: OptimizationLevel[] = [
  'potato',
  'low',
  'medium',
  'high',
  'ultra',
];

export default function GamesScreen() {
  const [games, setGames] = useState<GameProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [selectedGame, setSelectedGame] = useState<GameProfile | null>(null);
  const [newGame, setNewGame] = useState({
    package_name: '',
    game_name: '',
    icon_url: '',
    optimization_level: 'medium' as OptimizationLevel,
    cpu_boost: false,
    ram_clear_before: true,
    block_notifications: true,
    reduce_animations: false,
    custom_resolution_scale: 1.0,
    disable_shadows: false,
    disable_effects: false,
    auto_optimize: true,
  });

  useEffect(() => {
    loadGames();
  }, []);

  const loadGames = async () => {
    try {
      const profiles = await DatabaseService.getGameProfiles();
      setGames(profiles);
    } catch (error) {
      console.error('Error loading games:', error);
    }
  };

  const addGame = async () => {
    if (!newGame.package_name || !newGame.game_name) {
      Alert.alert('Error', 'El nombre del paquete y del juego son requeridos');
      return;
    }

    try {
      await DatabaseService.createGameProfile(newGame);
      setShowAddModal(false);
      resetNewGame();
      loadGames();
      Alert.alert('Éxito', 'Juego agregado correctamente');
    } catch (error) {
      console.error('Error adding game:', error);
      Alert.alert('Error', 'No se pudo agregar el juego');
    }
  };

  const updateGame = async () => {
    if (!selectedGame) return;

    try {
      await DatabaseService.updateGameProfile(selectedGame.id, selectedGame);
      setShowConfigModal(false);
      setSelectedGame(null);
      loadGames();
      Alert.alert('Éxito', 'Configuración guardada');
    } catch (error) {
      console.error('Error updating game:', error);
      Alert.alert('Error', 'No se pudo actualizar el juego');
    }
  };

  const deleteGame = async () => {
    if (!selectedGame) return;

    Alert.alert('Confirmar', '¿Eliminar este juego?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: async () => {
          try {
            await DatabaseService.deleteGameProfile(selectedGame.id);
            setShowConfigModal(false);
            setSelectedGame(null);
            loadGames();
          } catch (error) {
            console.error('Error deleting game:', error);
            Alert.alert('Error', 'No se pudo eliminar el juego');
          }
        },
      },
    ]);
  };

  const applyOptimizations = async (game: GameProfile) => {
    try {
      await optimizationService.applyOptimizations(game);
      Alert.alert(
        'Optimizaciones aplicadas',
        `Se aplicaron las optimizaciones para ${game.game_name}`
      );
    } catch (error) {
      console.error('Error applying optimizations:', error);
      Alert.alert('Error', 'No se pudieron aplicar las optimizaciones');
    }
  };

  const resetNewGame = () => {
    setNewGame({
      package_name: '',
      game_name: '',
      icon_url: '',
      optimization_level: 'medium',
      cpu_boost: false,
      ram_clear_before: true,
      block_notifications: true,
      reduce_animations: false,
      custom_resolution_scale: 1.0,
      disable_shadows: false,
      disable_effects: false,
      auto_optimize: true,
    });
  };

  const filteredGames = games.filter(
    (game) =>
      game.game_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.package_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Mis Juegos</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setShowAddModal(true)}>
          <Plus size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#9ca3af" />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar juegos..."
          placeholderTextColor="#6b7280"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView style={styles.gamesList}>
        {filteredGames.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              {searchQuery
                ? 'No se encontraron juegos'
                : 'Agrega tus primeros juegos'}
            </Text>
          </View>
        ) : (
          filteredGames.map((game) => (
            <GameCard
              key={game.id}
              game={game}
              onPress={() => applyOptimizations(game)}
              onConfigure={() => {
                setSelectedGame(game);
                setShowConfigModal(true);
              }}
            />
          ))
        )}
      </ScrollView>

      <Modal
        visible={showAddModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowAddModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Agregar Juego</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <X size={24} color="#9ca3af" />
              </TouchableOpacity>
            </View>

            <ScrollView>
              <Text style={styles.label}>Nombre del Juego</Text>
              <TextInput
                style={styles.input}
                placeholder="Ej: Free Fire"
                placeholderTextColor="#6b7280"
                value={newGame.game_name}
                onChangeText={(text) =>
                  setNewGame({ ...newGame, game_name: text })
                }
              />

              <Text style={styles.label}>Nombre del Paquete</Text>
              <TextInput
                style={styles.input}
                placeholder="Ej: com.dts.freefireth"
                placeholderTextColor="#6b7280"
                value={newGame.package_name}
                onChangeText={(text) =>
                  setNewGame({ ...newGame, package_name: text })
                }
              />

              <Text style={styles.label}>Nivel de Optimización</Text>
              <View style={styles.levelButtons}>
                {optimizationLevels.map((level) => (
                  <TouchableOpacity
                    key={level}
                    style={[
                      styles.levelButton,
                      newGame.optimization_level === level &&
                        styles.levelButtonActive,
                    ]}
                    onPress={() =>
                      setNewGame({ ...newGame, optimization_level: level })
                    }>
                    <Text
                      style={[
                        styles.levelButtonText,
                        newGame.optimization_level === level &&
                          styles.levelButtonTextActive,
                      ]}>
                      {level.toUpperCase()}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={styles.switchRow}>
                <Text style={styles.switchLabel}>CPU Boost</Text>
                <Switch
                  value={newGame.cpu_boost}
                  onValueChange={(value) =>
                    setNewGame({ ...newGame, cpu_boost: value })
                  }
                  trackColor={{ false: '#374151', true: '#10b981' }}
                  thumbColor="#fff"
                />
              </View>

              <View style={styles.switchRow}>
                <Text style={styles.switchLabel}>Limpiar RAM antes</Text>
                <Switch
                  value={newGame.ram_clear_before}
                  onValueChange={(value) =>
                    setNewGame({ ...newGame, ram_clear_before: value })
                  }
                  trackColor={{ false: '#374151', true: '#10b981' }}
                  thumbColor="#fff"
                />
              </View>

              <View style={styles.switchRow}>
                <Text style={styles.switchLabel}>Bloquear notificaciones</Text>
                <Switch
                  value={newGame.block_notifications}
                  onValueChange={(value) =>
                    setNewGame({ ...newGame, block_notifications: value })
                  }
                  trackColor={{ false: '#374151', true: '#10b981' }}
                  thumbColor="#fff"
                />
              </View>

              <View style={styles.switchRow}>
                <Text style={styles.switchLabel}>Auto-optimizar</Text>
                <Switch
                  value={newGame.auto_optimize}
                  onValueChange={(value) =>
                    setNewGame({ ...newGame, auto_optimize: value })
                  }
                  trackColor={{ false: '#374151', true: '#10b981' }}
                  thumbColor="#fff"
                />
              </View>

              <TouchableOpacity style={styles.saveButton} onPress={addGame}>
                <Text style={styles.saveButtonText}>Agregar Juego</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showConfigModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowConfigModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {selectedGame && (
              <>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>
                    {selectedGame.game_name}
                  </Text>
                  <TouchableOpacity onPress={() => setShowConfigModal(false)}>
                    <X size={24} color="#9ca3af" />
                  </TouchableOpacity>
                </View>

                <ScrollView>
                  <Text style={styles.label}>Nivel de Optimización</Text>
                  <View style={styles.levelButtons}>
                    {optimizationLevels.map((level) => (
                      <TouchableOpacity
                        key={level}
                        style={[
                          styles.levelButton,
                          selectedGame.optimization_level === level &&
                            styles.levelButtonActive,
                        ]}
                        onPress={() =>
                          setSelectedGame({
                            ...selectedGame,
                            optimization_level: level,
                          })
                        }>
                        <Text
                          style={[
                            styles.levelButtonText,
                            selectedGame.optimization_level === level &&
                              styles.levelButtonTextActive,
                          ]}>
                          {level.toUpperCase()}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>CPU Boost</Text>
                    <Switch
                      value={selectedGame.cpu_boost}
                      onValueChange={(value) =>
                        setSelectedGame({ ...selectedGame, cpu_boost: value })
                      }
                      trackColor={{ false: '#374151', true: '#10b981' }}
                      thumbColor="#fff"
                    />
                  </View>

                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>Limpiar RAM antes</Text>
                    <Switch
                      value={selectedGame.ram_clear_before}
                      onValueChange={(value) =>
                        setSelectedGame({
                          ...selectedGame,
                          ram_clear_before: value,
                        })
                      }
                      trackColor={{ false: '#374151', true: '#10b981' }}
                      thumbColor="#fff"
                    />
                  </View>

                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>
                      Bloquear notificaciones
                    </Text>
                    <Switch
                      value={selectedGame.block_notifications}
                      onValueChange={(value) =>
                        setSelectedGame({
                          ...selectedGame,
                          block_notifications: value,
                        })
                      }
                      trackColor={{ false: '#374151', true: '#10b981' }}
                      thumbColor="#fff"
                    />
                  </View>

                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>Reducir animaciones</Text>
                    <Switch
                      value={selectedGame.reduce_animations}
                      onValueChange={(value) =>
                        setSelectedGame({
                          ...selectedGame,
                          reduce_animations: value,
                        })
                      }
                      trackColor={{ false: '#374151', true: '#10b981' }}
                      thumbColor="#fff"
                    />
                  </View>

                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>Desactivar sombras</Text>
                    <Switch
                      value={selectedGame.disable_shadows}
                      onValueChange={(value) =>
                        setSelectedGame({
                          ...selectedGame,
                          disable_shadows: value,
                        })
                      }
                      trackColor={{ false: '#374151', true: '#10b981' }}
                      thumbColor="#fff"
                    />
                  </View>

                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>Desactivar efectos</Text>
                    <Switch
                      value={selectedGame.disable_effects}
                      onValueChange={(value) =>
                        setSelectedGame({
                          ...selectedGame,
                          disable_effects: value,
                        })
                      }
                      trackColor={{ false: '#374151', true: '#10b981' }}
                      thumbColor="#fff"
                    />
                  </View>

                  <View style={styles.switchRow}>
                    <Text style={styles.switchLabel}>Auto-optimizar</Text>
                    <Switch
                      value={selectedGame.auto_optimize}
                      onValueChange={(value) =>
                        setSelectedGame({
                          ...selectedGame,
                          auto_optimize: value,
                        })
                      }
                      trackColor={{ false: '#374151', true: '#10b981' }}
                      thumbColor="#fff"
                    />
                  </View>

                  <TouchableOpacity
                    style={styles.saveButton}
                    onPress={updateGame}>
                    <Text style={styles.saveButtonText}>Guardar Cambios</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.deleteButton}
                    onPress={deleteGame}>
                    <Text style={styles.deleteButtonText}>Eliminar Juego</Text>
                  </TouchableOpacity>
                </ScrollView>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 48,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#f9fafb',
  },
  addButton: {
    backgroundColor: '#10b981',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1f2937',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginHorizontal: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: '#f9fafb',
  },
  gamesList: {
    flex: 1,
    paddingHorizontal: 16,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: '#6b7280',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#1f2937',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#f9fafb',
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#9ca3af',
    marginBottom: 8,
    marginTop: 16,
  },
  input: {
    backgroundColor: '#111827',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#f9fafb',
    borderWidth: 1,
    borderColor: '#374151',
  },
  levelButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  levelButton: {
    backgroundColor: '#374151',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  levelButtonActive: {
    backgroundColor: '#10b981',
  },
  levelButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#9ca3af',
  },
  levelButtonTextActive: {
    color: '#fff',
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  switchLabel: {
    fontSize: 16,
    color: '#f9fafb',
  },
  saveButton: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
  deleteButton: {
    backgroundColor: '#ef4444',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 12,
  },
  deleteButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
});
