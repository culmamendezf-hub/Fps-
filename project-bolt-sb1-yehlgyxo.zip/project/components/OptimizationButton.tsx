import { TouchableOpacity, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { Video as LucideIcon } from 'lucide-react-native';

interface OptimizationButtonProps {
  icon: LucideIcon;
  label: string;
  onPress: () => void;
  isActive?: boolean;
  isLoading?: boolean;
  color?: string;
}

export default function OptimizationButton({
  icon: Icon,
  label,
  onPress,
  isActive = false,
  isLoading = false,
  color = '#10b981',
}: OptimizationButtonProps) {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        isActive && { ...styles.active, borderColor: color },
      ]}
      onPress={onPress}
      disabled={isLoading}>
      <Icon size={28} color={isActive ? color : '#9ca3af'} />
      {isLoading && (
        <ActivityIndicator
          size="small"
          color={color}
          style={styles.loader}
        />
      )}
      <Text style={[styles.label, isActive && { color }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100,
    borderWidth: 2,
    borderColor: '#374151',
    margin: 4,
  },
  active: {
    backgroundColor: '#10b98120',
  },
  loader: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: '#9ca3af',
    marginTop: 8,
    textAlign: 'center',
  },
});
