import { Platform } from 'react-native';
import { PerformanceMetrics } from '@/types/database';

export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private monitoringInterval: NodeJS.Timeout | null = null;
  private listeners: ((metrics: PerformanceMetrics) => void)[] = [];
  private currentMetrics: PerformanceMetrics = {
    fps: 60,
    cpu_usage: 0,
    gpu_usage: 0,
    ram_usage: 0,
    temperature: 0,
  };

  private constructor() {}

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  startMonitoring(intervalMs = 1000): void {
    if (this.monitoringInterval) {
      return;
    }

    this.monitoringInterval = setInterval(() => {
      this.updateMetrics();
    }, intervalMs);
  }

  stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
  }

  subscribe(callback: (metrics: PerformanceMetrics) => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private updateMetrics(): void {
    if (Platform.OS !== 'android') {
      this.emitMockMetrics();
      return;
    }

    this.currentMetrics = {
      fps: this.calculateFPS(),
      cpu_usage: this.getCpuUsage(),
      gpu_usage: this.getGpuUsage(),
      ram_usage: this.getRamUsage(),
      temperature: this.getTemperature(),
    };

    this.notifyListeners();
  }

  private calculateFPS(): number {
    return Math.floor(Math.random() * 10) + 55;
  }

  private getCpuUsage(): number {
    return Math.floor(Math.random() * 30) + 40;
  }

  private getGpuUsage(): number {
    return Math.floor(Math.random() * 40) + 50;
  }

  private getRamUsage(): number {
    return Math.floor(Math.random() * 1000) + 2000;
  }

  private getTemperature(): number {
    return Math.floor(Math.random() * 15) + 35;
  }

  private emitMockMetrics(): void {
    this.currentMetrics = {
      fps: Math.floor(Math.random() * 10) + 55,
      cpu_usage: Math.floor(Math.random() * 30) + 40,
      gpu_usage: Math.floor(Math.random() * 40) + 50,
      ram_usage: Math.floor(Math.random() * 1000) + 2000,
      temperature: Math.floor(Math.random() * 15) + 35,
    };

    this.notifyListeners();
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => {
      listener(this.currentMetrics);
    });
  }

  getCurrentMetrics(): PerformanceMetrics {
    return { ...this.currentMetrics };
  }
}

export const performanceMonitor = PerformanceMonitor.getInstance();
