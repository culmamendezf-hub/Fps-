import { Platform } from 'react-native';

export class ShizukuService {
  private static instance: ShizukuService;
  private isShizukuAvailable = false;
  private isPermissionGranted = false;

  private constructor() {}

  static getInstance(): ShizukuService {
    if (!ShizukuService.instance) {
      ShizukuService.instance = new ShizukuService();
    }
    return ShizukuService.instance;
  }

  async checkShizukuAvailability(): Promise<boolean> {
    if (Platform.OS !== 'android') {
      return false;
    }

    try {
      return this.isShizukuAvailable;
    } catch (error) {
      console.error('Error checking Shizuku availability:', error);
      return false;
    }
  }

  async requestShizukuPermission(): Promise<boolean> {
    if (Platform.OS !== 'android') {
      return false;
    }

    try {
      return this.isPermissionGranted;
    } catch (error) {
      console.error('Error requesting Shizuku permission:', error);
      return false;
    }
  }

  async executeShellCommand(command: string): Promise<string> {
    if (Platform.OS !== 'android') {
      return 'Platform not supported';
    }

    if (!this.isShizukuAvailable || !this.isPermissionGranted) {
      throw new Error('Shizuku not available or permission not granted');
    }

    try {
      console.log('Mock executing command:', command);
      return 'Command executed successfully (mock)';
    } catch (error) {
      console.error('Error executing shell command:', error);
      throw error;
    }
  }

  async setAnimationScale(scale: number): Promise<void> {
    const commands = [
      `settings put global window_animation_scale ${scale}`,
      `settings put global transition_animation_scale ${scale}`,
      `settings put global animator_duration_scale ${scale}`,
    ];

    for (const cmd of commands) {
      await this.executeShellCommand(cmd);
    }
  }

  async killBackgroundProcesses(excludePackages: string[] = []): Promise<void> {
    const excludeApps = [
      'com.android.systemui',
      'com.android.launcher',
      ...excludePackages,
    ];

    const cmd = `am kill-all --exclude ${excludeApps.join(',')}`;
    await this.executeShellCommand(cmd);
  }

  async setCpuGovernor(governor: 'performance' | 'powersave' | 'balanced'): Promise<void> {
    const cpuPath = '/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor';
    await this.executeShellCommand(`echo ${governor} > ${cpuPath}`);
  }

  async clearRamCache(): Promise<void> {
    await this.executeShellCommand('sync');
    await this.executeShellCommand('echo 3 > /proc/sys/vm/drop_caches');
  }

  async setGpuTurboMode(enabled: boolean): Promise<void> {
    const value = enabled ? '1' : '0';
    await this.executeShellCommand(
      `setprop debug.hwui.renderer ${enabled ? 'skiagl' : 'skiavk'}`
    );
  }

  async optimizeForGame(packageName: string): Promise<void> {
    const commands = [
      `cmd package set-home-activity ${packageName}`,
      `dumpsys deviceidle whitelist +${packageName}`,
      `cmd appops set ${packageName} RUN_IN_BACKGROUND allow`,
    ];

    for (const cmd of commands) {
      await this.executeShellCommand(cmd);
    }
  }

  async setAppPriority(packageName: string, priority: 'high' | 'normal'): Promise<void> {
    const pid = await this.getAppPid(packageName);
    if (pid) {
      const niceValue = priority === 'high' ? -20 : 0;
      await this.executeShellCommand(`renice ${niceValue} ${pid}`);
    }
  }

  private async getAppPid(packageName: string): Promise<string | null> {
    try {
      const result = await this.executeShellCommand(
        `pidof ${packageName}`
      );
      return result.trim();
    } catch {
      return null;
    }
  }
}

export const shizukuService = ShizukuService.getInstance();
